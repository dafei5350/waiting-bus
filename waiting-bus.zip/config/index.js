
const qqmapsdk= 'QE3BZ-R7ICD-ZIS42-HCM3D-N2GY5-CZFWQ'
const sig = 'YNslppjFOs8o15vdw5edjv776NPXgLb'
// 5AEBZ-L5OKJ-ZSCF7-FKQ6R-RDPTH-TVBHT
module.exports ={

  qqmapsdk,
  sig

}