export default {
	// 本地
	LOCAL_SERVER: "http://127.0.0.1:3000/v1/wechat/",
	// 获取天气
	WEATHER_HOST: "https://wis.qq.com/weather/common?source=pc&weather_type=observe",



	
}